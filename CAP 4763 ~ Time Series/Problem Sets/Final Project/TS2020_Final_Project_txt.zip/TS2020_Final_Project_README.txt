Data List: TS2020 Final Project
Data Updated: 2021-04-16

FRED (Federal Reserve Economic Data)
Link: https://fred.stlouisfed.org
Help: https://fredhelp.stlouisfed.org
Economic Research Division
Federal Reserve Bank of St. Louis

Series ID                                                             
----------------------------------------------------------------------
SMU12455400500000001                                                  

Title
----------------------------------------------------------------------
All Employees: Total Private in The Villages, FL (MSA)                

Source
----------------------------------------------------------------------
Federal Reserve Bank of St. Louis                                     
U.S. Bureau of Labor Statistics                                       

Release
----------------------------------------------------------------------
State and Metro Area Employment, Hours, and Earnings                  

Units
----------------------------------------------------------------------
Thousands of Persons                                                  

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               



Series ID                                                             
----------------------------------------------------------------------
SMU12455400500000002                                                  

Title
----------------------------------------------------------------------
Average Weekly Hours of All Employees: Total Private in The Villages, 
FL (MSA)                                                              

Source
----------------------------------------------------------------------
Federal Reserve Bank of St. Louis                                     
U.S. Bureau of Labor Statistics                                       

Release
----------------------------------------------------------------------
State and Metro Area Employment, Hours, and Earnings                  

Units
----------------------------------------------------------------------
Hours per Week                                                        

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               



Series ID                                                             
----------------------------------------------------------------------
SMU12455400500000003                                                  

Title
----------------------------------------------------------------------
Average Hourly Earnings of All Employees: Total Private in The        
Villages, FL (MSA)                                                    

Source
----------------------------------------------------------------------
Federal Reserve Bank of St. Louis                                     
U.S. Bureau of Labor Statistics                                       

Release
----------------------------------------------------------------------
State and Metro Area Employment, Hours, and Earnings                  

Units
----------------------------------------------------------------------
Dollars per Hour                                                      

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               



Series ID                                                             
----------------------------------------------------------------------
SMU12455400500000011                                                  

Title
----------------------------------------------------------------------
Average Weekly Earnings of All Employees: Total Private in The        
Villages, FL (MSA)                                                    

Source
----------------------------------------------------------------------
Federal Reserve Bank of St. Louis                                     
U.S. Bureau of Labor Statistics                                       

Release
----------------------------------------------------------------------
State and Metro Area Employment, Hours, and Earnings                  

Units
----------------------------------------------------------------------
Dollars per Week                                                      

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               



Series ID                                                             
----------------------------------------------------------------------
SMU12455400800000001                                                  

Title
----------------------------------------------------------------------
All Employees: Private Service Providing in The Villages, FL (MSA)    

Source
----------------------------------------------------------------------
Federal Reserve Bank of St. Louis                                     
U.S. Bureau of Labor Statistics                                       

Release
----------------------------------------------------------------------
State and Metro Area Employment, Hours, and Earnings                  

Units
----------------------------------------------------------------------
Thousands of Persons                                                  

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               



